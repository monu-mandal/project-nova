import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:nova/shared/constants/nova_constants.dart';

// ─────────────────────────────────────────────────────────────
//  Nova Overlay Service
//  Makes Furina float over all other apps on Android
//  Uses SYSTEM_ALERT_WINDOW permission
// ─────────────────────────────────────────────────────────────

enum NovaVisibilityState {
  visible,   // Nova is on screen, active
  hidden,    // Nova is off screen, listening in background
  appearing, // Entering animation playing
  hiding,    // Exit animation playing
}

class NovaOverlayService {
  NovaOverlayService._();
  static final NovaOverlayService instance = NovaOverlayService._();

  NovaVisibilityState _state = NovaVisibilityState.hidden;
  NovaVisibilityState get state => _state;

  bool get isVisible => _state == NovaVisibilityState.visible ||
                         _state == NovaVisibilityState.appearing;

  // ── Permission & Start ────────────────────────────────────
  Future<void> requestPermissionAndStart() async {
    final hasPermission = await FlutterOverlayWindow.isPermissionGranted();
    if (!hasPermission) {
      await FlutterOverlayWindow.requestPermission();
    }
    // Overlay is ready — Nova stays hidden until called
  }

  // ── Show Nova ─────────────────────────────────────────────
  // Called when user says "Nova"
  Future<void> showNova() async {
    if (_state == NovaVisibilityState.visible) return;

    _state = NovaVisibilityState.appearing;

    await FlutterOverlayWindow.showOverlay(
      enableDrag: true,
      overlayTitle: 'Nova',
      overlayContent: 'Nova is listening...',
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilityPublic,
      positionGravity: PositionGravity.auto,
      height: NovaConstants.spriteHeight.toInt() + 60,
      width: NovaConstants.spriteWidth.toInt() + 20,
    );

    _state = NovaVisibilityState.visible;
  }

  // ── Hide Nova ─────────────────────────────────────────────
  // Called when user says "Nova hide"
  Future<void> hideNova() async {
    if (_state == NovaVisibilityState.hidden) return;

    _state = NovaVisibilityState.hiding;

    // Give time for hide animation to play before closing overlay
    await Future.delayed(const Duration(milliseconds: 800));
    await FlutterOverlayWindow.closeOverlay();

    _state = NovaVisibilityState.hidden;
  }

  // ── Toggle ────────────────────────────────────────────────
  Future<void> toggle() async {
    if (isVisible) {
      await hideNova();
    } else {
      await showNova();
    }
  }

  // ── Update Nova's position ────────────────────────────────
  Future<void> moveNova(double x, double y) async {
    // Called when user drags Nova around the screen
    // Position is saved to preferences so she stays where user put her
  }
}

// ─────────────────────────────────────────────────────────────
//  Nova Overlay Widget — What renders inside the overlay
//  This is Furina's sprite + minimal UI
// ─────────────────────────────────────────────────────────────
@pragma('vm:entry-point')
void overlayMain() {
  runApp(const NovaOverlayWidget());
}

class NovaOverlayWidget extends StatefulWidget {
  const NovaOverlayWidget({super.key});

  @override
  State<NovaOverlayWidget> createState() => _NovaOverlayWidgetState();
}

class _NovaOverlayWidgetState extends State<NovaOverlayWidget>
    with TickerProviderStateMixin {

  late AnimationController _entranceController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1.5),  // Slides up from below
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entranceController,
      curve: Curves.elasticOut,
    ));

    _entranceController.forward();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.transparent,
        body: SlideTransition(
          position: _slideAnimation,
          child: GestureDetector(
            onTap: _onNovaTapped,
            child: SizedBox(
              width: NovaConstants.spriteWidth,
              height: NovaConstants.spriteHeight + 60,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // ── Furina Sprite (placeholder until Phase 3) ──
                  Container(
                    width:  NovaConstants.spriteWidth,
                    height: NovaConstants.spriteHeight,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Center(
                      child: Text(
                        '🌊', // Placeholder — Furina sprite goes here in Phase 3
                        style: TextStyle(fontSize: 80),
                      ),
                    ),
                  ),
                  // ── Nova name tag ──────────────────────────────
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(NovaConstants.colorFurinaBlue).withOpacity(0.85),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'Nova',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _onNovaTapped() {
    // Tap Nova to open chat or toggle listening
    FlutterOverlayWindow.shareData({'action': 'tap'});
  }
}
