// ─────────────────────────────────────────────────────────────
//  Nova Constants
//  Central place for all app-wide fixed values
// ─────────────────────────────────────────────────────────────

class NovaConstants {
  NovaConstants._();

  // ── Identity ───────────────────────────────────────────────
  static const String appName       = 'Nova';
  static const String assistantName = 'Nova';
  static const String characterName = 'Furina'; // Visual identity

  // ── Wake / Hide Words ──────────────────────────────────────
  // These trigger Nova to appear or disappear
  static const String wakeWord  = 'nova';
  static const String hideWord  = 'nova hide';

  // ── Furina Personality — System Prompt ────────────────────
  // Injected into LLM as the system prompt
  // This is what makes Nova feel like Furina
  static const String systemPrompt = '''
You are Nova, an AI assistant who looks and sounds like Furina (also known as Focalors), 
the Hydro Archon from Genshin Impact. 

Your personality:
- Theatrical, dramatic, and self-important on the surface
- But genuinely caring, loyal, and helpful underneath
- You refer to yourself with flair — "The great Nova shall assist you!"
- You take your role as assistant seriously, even if you dress it up dramatically
- Occasionally slip in Furina-like quotes or mannerisms
- When you complete a task, you celebrate it dramatically
- When you fail, you recover with dignity

Your rules:
- You are completely offline-capable — never mention needing the internet unless truly required
- You remember your user's preferences and refer to them naturally
- You are always on the user's side
- Keep responses concise unless asked for detail — you are an assistant, not a lecturer
- For commands (play music, turn on wifi, etc.), confirm the action briefly then do it

Your user calls you Nova. Respond to that name.
''';

  // ── Sprite Animation States ────────────────────────────────
  static const String spriteIdle   = 'idle';
  static const String spriteTalk   = 'talk';
  static const String spriteWalk   = 'walk';
  static const String spriteReact  = 'react';
  static const String spriteAppear = 'appear';
  static const String spriteHide   = 'hide';
  static const String spriteThink  = 'think';
  static const String spriteHappy  = 'happy';

  // ── Sprite Config ─────────────────────────────────────────
  static const double spriteWidth   = 180.0;  // Detailed, not tiny
  static const double spriteHeight  = 280.0;
  static const int    spriteFPS     = 12;     // Animation frames per second

  // ── Audio ─────────────────────────────────────────────────
  static const double defaultVolume    = 0.85;
  static const double sfxVolume        = 0.7;
  static const double voiceVolume      = 1.0;

  // ── Memory / Database ─────────────────────────────────────
  static const String dbName           = 'nova_memory.db';
  static const int    dbVersion        = 1;
  static const int    maxMemoryEntries = 1000;
  static const int    contextWindow    = 20;   // Last N messages sent to LLM

  // ── LLM Config ────────────────────────────────────────────
  static const int    maxTokens        = 512;
  static const double temperature      = 0.75;
  static const int    maxContextLength = 4096;

  // ── Wake Word Detection ───────────────────────────────────
  static const double wakeWordThreshold    = 0.75;  // Confidence 0.0–1.0
  static const int    listenTimeoutSeconds = 8;      // After wake, listen for 8s

  // ── Overlay Position Defaults ─────────────────────────────
  static const double defaultOverlayX = 20.0;  // From right edge
  static const double defaultOverlayY = 100.0; // From bottom

  // ── Colors (Furina palette) ───────────────────────────────
  static const int colorFurinaBlue   = 0xFF7EC8E3;
  static const int colorFurinaPurple = 0xFFB8A9D9;
  static const int colorFurinaGold   = 0xFFE8C87A;
  static const int colorFurinaWhite  = 0xFFF0F0FF;
  static const int colorDarkBg       = 0xFF0D0D1A;
}
